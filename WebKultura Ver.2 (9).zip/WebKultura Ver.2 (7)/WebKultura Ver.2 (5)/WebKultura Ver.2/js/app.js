

'use strict';








class App{
	constructor(){

		var database = firebase.database();
		let VideoData = [];
		let videos = firebase.database().ref('Videos').once('value',(snapshot)=>{
		snapshot.forEach(function(childSnapshot){
			
			VideoData.push({"ChannelId":childSnapshot.val().ChannelId, "Genre":childSnapshot.val().Genre,"Thumbnail":childSnapshot.val().Thumbnail,"Title":childSnapshot.val().Title, "VideoDate":childSnapshot.val().VideoDate,"VideoDescription":childSnapshot.val().VideoDescription,"VideoLikes":childSnapshot.val().VideoLikes,"VideoURL":childSnapshot.val().VideoURL,"Videoid":childSnapshot.val().Videoid})
			});

			component.PushVideo(VideoData);

			});



	
		let MemberData = [];
		let member = firebase.database().ref('Member').once('value',(snapshot)=>{
		snapshot.forEach(function(childSnapshot){
			
			MemberData.push({"UserName":childSnapshot.val().UserName, "Password":childSnapshot.val().Password, "MemberId":childSnapshot.val().MemberId, "ChannelSaved":childSnapshot.val().ChannelSaved})
			});

			component.PushMember(MemberData);

			});

		let AdminData = [];
		let admin = firebase.database().ref('Admin').once('value',(snapshot)=>{
		snapshot.forEach(function(childSnapshot){
			
			AdminData.push({"UserName":childSnapshot.val().UserName, "Password":childSnapshot.val().Password, "AdminId":childSnapshot.val().AdminId})
			});

			component.PushAdmin(AdminData);

			});


		let ChannelData = [];
		let channel = firebase.database().ref('Channel').once('value',(snapshot)=>{
		snapshot.forEach(function(childSnapshot){

			ChannelData.push({"ChannelDescription":childSnapshot.val().ChannelDescription, "ChannelDate":childSnapshot.val().ChannelDate, "ChannelId":childSnapshot.val().ChannelId, "ChannelName":childSnapshot.val().ChannelName, "ChannelPicture":childSnapshot.val().ChannelPicture,"ChannelVideo":childSnapshot.val().ChannelVideo})
			});
				
			 component.PushChannel(ChannelData);

			});





		this.Videos=[];
		this.Channels=[];
		this.Members=[];
		this.Admin=[];


	}
		PushAdmin(admindata){
				for(let x=0;x< admindata.length;x++){
				this.Admin.push(admindata[x]);

		}

		}
		PushChannel(channeldata){
			for(let x=0;x< channeldata.length;x++){
				this.Channels.push(channeldata[x]);

		}
					component.indexPage();
				
		
	}
		PushVideo(videodata){


				for(let x=0;x< videodata.length;x++){
				this.Videos.push(videodata[x]);


				
			}

			
		}
		PushMember(memberdata){




			for(let x=0;x< memberdata.length;x++){
				this.Members.push(memberdata[x]);
				console.log(this.Members[x].ChannelSaved);

				
				
			}
			
  			


			
		}

		readsWhatNew(){
			let likes=[];

			for(let x=0;x<this.Videos.length;x++){
				
					likes.push(this.Videos[x].VideoLikes);
					likes.sort(function(a, b){return b-a});	

						
			}
			
			
			let top = likes.slice(0,3);
			
			let popularID=[];

			for(let x=0;x<likes.length;x++){
				for(let y=0;y<likes.length;y++){
					if(this.Videos[y].VideoLikes == top[x]){
						popularID.push(this.Videos[y].Videoid);
						
					}
				}
			}
		


			        
			let html=`
			<br>
			<blockquote>
     		<h5>Most Popular</h5>
   			 </blockquote>

			<div class="row">
		
			`;

			for(let x=0,count=0;x<popularID.length;x++){
				console.log(this.Videos[x].Videoid);
				console.log(this.Videos[popularID[x]].Videoid);	
				let ID = this.Videos[x].Videoid;
				console.log(ID);
						
							html+=`
						

				
			     	   <div class="col s3">
			     	   <a href="#" onclick="component.ReadGuestVideo('${this.Videos[popularID[x]].Videoid}');">
			          <div class="card z-depth-0" style="">
			          	<div class="hoverable">         
			            <div class="card-image" style="">
			              <img style ="height:170px" src="${this.Videos[popularID[x]].Thumbnail}">			              
			            </div>
			             

			          	</div>
			          	 <span class="card-title #757575 grey-text text-darken-1 center-align" ><h5>${this.Videos[popularID[x]].Title}</h5></span>
			          </div>
			          </a>
			        </div>
			     
			      	`;

			      	console.log("in" + this.Videos[popularID[x]].Videoid);
			    	












			      						count++;
										if(count==4){
											break;
										}
						
			}

			html+=`
		
 			</div>
			</div>

			<blockquote>
     		<h5>Recent Uploads</h5>
   			 </blockquote>

			<div class="row">
			`;


			for(let x= this.Videos.length-1,count = 0;x>=0;x--){
				let ID = this.Videos[x].Videoid;
				console.log("in again");
			html+=`

				
			    




			         <div class="col s4">
			     	   <a href="#" onclick="component.ReadGuestVideo('${ID}');">
			          <div class="card z-depth-0" style="">
			          	<div class="hoverable">         
			            <div class="card-image" style="">
			              <img style ="height:300px" src="${this.Videos[x].Thumbnail}">			              
			            </div>
			             

			          	</div>
			          	 <span class="card-title #757575 grey-text text-darken-1 center-align" ><h5>${this.Videos[x].Title}</h5></span>
			          </div>
			          </a>
			        </div>




			     
			      	`;
										count++;
										if(count==3){
											break;
										}


			}

			html+=`
			</div>
			</div>
			`;



			document.getElementById("WhatNew").innerHTML=html;
		}
		ReadBrowseGuest(){
			console.log("read guest");
			let	html=`
			<br>
			<blockquote>
     		<h5>All Videos</h5>
   			 </blockquote>

			<div class="row">
			`;


			for(let x=0;x<this.Videos.length;x++){
				let ID= this.Videos[x].Videoid;
			html+=`

				
			        <div class="col s3">
			     	   <a href="#" onclick="component.ReadGuestVideo('${ID}');">
			          <div class="card z-depth-0" style="">
			          	<div class="hoverable">         
			            <div class="card-image" style="">
			              <img style ="height:170px" src="${this.Videos[x].Thumbnail}">			              
			            </div>
			             

			          	</div>
			          	 <span class="card-title #757575 grey-text text-darken-1 center-align" ><h5>${this.Videos[x].Title}</h5></span>
			          </div>
			          </a>
			        </div>
			     
			      	`;

			}

			html+=`
			</div>
			</div>
			`;
			document.getElementById("Browse").innerHTML=html;
		}
		ReadChannelGuest(){
			
			let	html=`
			<br>
			<blockquote>
     		<h5>All Channels</h5>
   			 </blockquote>

			<div class="row">
			<div class="collection">
						`; 
							for(let x=0;x<this.Channels.length;x++){
								let ID = this.Channels[x].ChannelId;
								
								html+=`

				


        
    
    

        						<div id="hoverani" class="col s12 m6" href="#"onclick="component.ReadGuestViewChannel('${ID}')" style="cursor:pointer">
						          <div class="card #ff8f00 amber darken-3 hoverable">
						            <div class="card-content white-text">
						              <span class="card-title">${this.Channels[x].ChannelName}</span>
						              <p class="truncate">${this.Channels[x].ChannelDescription}</p>
						            </div>
						            
						          </div>
						        </div>









								`;
							}

						html+=`
			</div>
			  </div>
		

		
			`;
			document.getElementById("Channel").innerHTML=html;

		}
		ReadGuestVideo(key){
			
			let Cid = this.Videos[key].ChannelId;
			console.log(key);
			console.log(Cid);
			console.log(this.Channels[Cid].ChannelName);
			component.ShowGuestVideo();
			component.HideGuestChannel();
			component.HideGuestHome();
			component.HideGuestAbout();
			component.HideGuestRegister();

			let html=`
				
				<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.indexPage()" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.indexPage()">Home</a></li>
					        <li><a href="#" onclick="component.ReadGuestAbout()">About</a></li>
					      </ul>
					    </div>
				</nav>

				<div class="container">
				<div class="row">
					<div class="col m12" style="margin-top:2%">
								<div class="video-container">
							        <iframe width="500" height="200" src="${this.Videos[key].VideoURL}" frameborder="0" allowfullscreen></iframe>
							     </div>
					</div>
					<div class="col m6">
						<ul class="collection with-header">
					        <li class="collection-header"><h4>${this.Videos[key].Title}</h4></li>
					        <li class="collection-item">${this.Videos[key].VideoDescription}</li>
					        <li class="collection-item">Genre:
					        `;
					        for(let x=0; x<this.Videos[key].Genre.length;x++){
					        	html+=`
					        		${this.Videos[key].Genre[x]}

					        	`;
					        	if(x<this.Videos[key].Genre.length-1){
					        		html+=`
					        		,`;
					        	}
					        }

					        html+=`

					        </li>
					        
					      </ul>

					</div>
					<div class="col m6">
						<ul class="collection with-header">
					        <li class="collection-header"><h6>To Watch Channels you have to be a member, Why not <a href="#" onclick="component.ReadRegisterPage()">Sign up</a></h6></li>
					    </ul>
					</div>
					<div class="col m6">
						<ul class="collection with-header">
					        <li class="collection-header">View more of <a href="#" onclick="component.ReadGuestViewChannel('${Cid}')">${this.Channels[Cid].ChannelName}</a></li>
					    </ul>
					</div>
				</div>
				</div>



			`;
			
		document.getElementById("GuesViewVideo").innerHTML=html;



		}
		ReadGuestViewChannel(key){
			component.showGuestChannel();
			component.HideGuestHome();
			component.HideGuestVideo();
			component.HideGuestAbout();
			component.HideGuestRegister();
			console.log(key);


					
			
			let html=`
				<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.indexPage()" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.indexPage()">Home</a></li>
					        <li><a href="#" onclick="component.ReadGuestAbout()">About</a></li>
					      </ul>
					    </div>
				</nav>

				<div class="container" style="margin-top:3%;">
					<div class="row">
						<div class="col m6">
						<img class="responsive-img" src="${this.Channels[key].ChannelPicture}" style="height:300px">
						<div class="col m12" style="margin-left: -2%">
								<blockquote class="col m12"><h3>${this.Channels[key].ChannelName}</h3></blockquote>
								<div class="col m12">
									${this.Channels[key].ChannelDescription}
									</div>
						</div>
						</div>
						<div class="col m6">
									<table class="highlight">
								        <thead>
								          <tr>
								              <th>EPISODES</th>							         
								          </tr>
								        </thead>

								        <tbody>
								        `;





								          for(let x=0;x<this.Channels[key].ChannelVideo.length;x++){
								          	if(this.Channels[key].ChannelVideo[x] != " "){
								          		let id = this.Channels[key].ChannelVideo[x];
								          		let Vid = 0;
								          		let loc = 0;
								          		console.log(this.Channels[key].ChannelVideo[x])
								          		for(let y = 0; y<this.Videos.length;y++){
								          			if(this.Channels[key].ChannelVideo[x] == this.Videos[y].Videoid){
								          				Vid = this.Videos[y].Videoid;
								          				loc = y;
								          			}
								          		}
								          		console.log(Vid);
								          		

								          	html+=`

								          	<tr class="#ff8f00 amber darken-3 hoverable" style="cursor:pointer" onclick ="component.ReadGuestVideo('${loc}');">
								           		 <td><h6><a href="#" onclick ="component.ReadGuestVideo('${loc}');" class="#00695c #ffffff white-text">${this.Videos[loc].Title}</a></h6></td>				            
								         	 </tr>



								         	




								          	`;

								          	}
								          	else{
								          		html+=`


								          		<tr>
								          			<td>No Videos</td>
								          		</tr>
								          		`;
								          	}




								          }

								          html+=`
								        </tbody>
								      </table>
						</div>
						
					</div>

				</div>



			`;
		document.getElementById("GuestViewChannel").innerHTML=html;
		}
		ReadGuestAbout(){
			component.HideGuestHome();
			component.HideGuestVideo();
			component.HideGuestChannel();
			component.ShowGuestAbout();
			component.HideGuestRegister();
			console.log("in");
			let html=`
			<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.indexPage()" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.indexPage()">Home</a></li>
					        <li><a href="#" onclick="component.ReadGuestAbout()">About</a></li>
					      </ul>
					    </div>
				    </nav>


				    <div class="container" style="margin-top:5%">
				    	<div class="row">
				    		<div class="col m12 z-depth-1">
				    			<h1 class="center-align card-panel #00695c teal darken-3 #ffffff white-text"> WebKultura </h1>
				    			<p class="center-align">WebKultura is a website that promotes 3D/2D animations that revolves around promoting Filipino culture.</p>
				    			<br>
				    			<p class="center-align">The Goal of this platform is to help increase the cultural awareness of Filipino kids but also to promote Filipino culture around the globe</p>
				    			<p class="center-align">If you want to contribute a Video on our site</p>
				    			<p class="center-align"> contact us </p>
				    			<p class="center-align">kentesmalla@gmail.com</p>
				    			<p class="center-align">ifernandine@gmail.com</p>
				    		</div>
				    		

				    	</div>
				    </div>






			`;
			document.getElementById("GuestAbout").innerHTML=html;
		}
		ReadRegisterPage(){
			console.log("reg");
			component.ShowGuestRegister();
			component.HideGuestHome();
			component.HideGuestVideo();
			component.HideGuestChannel();
			component.HideGuestAbout();
			let html =`	
				<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.indexPage()" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.indexPage()">Home</a></li>
					        <li><a href="#" onclick="component.ReadGuestAbout()">About</a></li>
					      </ul>
					    </div>
				    </nav>

				<div class="container" style="margin-top: 3%;">
					<div class="row center-align z-depth-3" style="height: 430px">

						<div class="col m12 ">
							<blockquote><h2>Register</h2></blockquote>
						</div>
						<div class="col m6 offset-m3">

						<div class="input-field col s12 ">
				          <input id="Register_User" type="text" class="validate">
				          <label for="Register_User">Username</label>
				        </div>

				        <div class="input-field col s12">
				          <input id="Register_Password" type="password" class="validate">
				          <label for="Register_Password">Password</label>
				        </div>

				        <div class="input-field col s12">
				          <input id="RegisterConfirm_Password" type="password" class="validate">
				          <label for="RegisterConfirm_Password">Confirm Password</label>
				        </div>
				        <div id="Error">
				        	
				        </div>

				        <div class="col s6 offset-s3">
				        	<a class="waves-effect waves-light btn" onclick="component.ReadRegisterUser()">Sign Up</a>
				        </div>

				        </div>
				        <br>



					</div>
				</div>

			`;

			document.getElementById("GuestRegister").innerHTML=html;
		}
		ReadRegisterUser(){

				


				let register_user = document.getElementById('Register_User').value;
				let register_pass = document.getElementById('Register_Password').value;
				let register_conpass = document.getElementById('RegisterConfirm_Password').value;
				let userid = firebase.database().ref().child('Member').push().key;


	

				 if (register_user==null || register_user=="",register_pass==null || register_pass=="",register_conpass==null || register_conpass=="")
			        {
			            

			        	let html =`
			        	<p class="#c62828 red-text text-darken-3">Please fill up all the information</p>
			        	`;
			        	document.getElementById("Error").innerHTML=html;


			        }
			        else if(register_pass==register_conpass){
			        	
			        	
			        	for(let x = 0; x < this.Members.length;x++){
			        			console.log(x);
			        		if(this.Members[x].UserName == register_user){
			        			
			        				let html =`
						        	<p class="#c62828 red-text text-darken-3">Username already taken</p>
						        	`;
						        	document.getElementById("Error").innerHTML=html;
						        	break;
						        	
			        		}	  
			        		else if(this.Members.length-1 ==x){
			        				console.log("pushed");
			        				let data = {
									UserName : register_user,
									Password : register_pass,
									MemberId: this.Members.length,
									ChannelSaved : [""],
							
								}
								this.Members.push(data);
							
								let updates = {};
								updates['/Member/'+userid] = data;

								 firebase.database().ref().update(updates);
								Materialize.toast('Successfully signed up', 4000);
								component.indexPage();
			        			}      			


			        	}
			        	


			        }
			        else if(register_pass!=register_conpass){
			        	let html =`
			        	<p class="#c62828 red-text text-darken-3">Password does not match</p>
			        	`;
			        	document.getElementById("Error").innerHTML=html;
			        }






				
		}

		ReadLogin(){
			let register_user = document.getElementById('Username').value;
			let register_pass = document.getElementById('password').value;
				let y=0;
			let Users = firebase.database().ref('Member').once('value', 
		      (userId)=>{
		      	let x= 0;
		      	
		        userId.forEach(function(snapshot) {
		        	if(register_user == snapshot.val().UserName && register_pass == snapshot.val().Password){
		        		Materialize.toast('Successfully Login', 4000);
		        		component.MemberHome(snapshot.val().MemberId);
		        		return;
		        	}
		        	else if(register_user == snapshot.val().UserName && register_pass != snapshot.val().Password){
		        		Materialize.toast('Incorrect password', 4000);
		        	}


		            }); 
		      
		       
  			});


  			let admins = firebase.database().ref('Admin').once('value', 
		      (adminId)=>{
		      	let x= 0;
		      	
		        adminId.forEach(function(snapshot) {
		        	if(register_user == snapshot.val().UserName && register_pass == snapshot.val().Password){
		        		Materialize.toast('Successfully Login', 4000);
		        		component.AdminHome(snapshot.val().AdminId);
		        		return;
		        	}
		        	else if(register_user == snapshot.val().UserName && register_pass != snapshot.val().Password){
		        		Materialize.toast('Incorrect password', 4000);
		        	}
		        	else{
		        		x++;

		        		if (x==userId.numChildren()){
		        			Materialize.toast('Incorrect username and password', 4000);
		        		}
		        		

		        	}

		            }); 
		      
		       
  			});



			


		}

			AdminHome(keyid){
			$(document).ready(function(){
    $('.collapsible').collapsible();
  });

			$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
						console.log("Admin");
					component.HideAllGuest();
					component.HideAdminAddVideo();
					component.HideAdminAddChannelPage();
					component.HideAdminEditVideoPage();
					component.HideAdminEditChannelPage();

					let html =`
						<div id="AllAdmin">
							<div id="Adminpage">
											<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.AdminHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.AdminHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					    </div>
					</nav>


								<div class="row ">
							 <div id="Register" class="collection col s2 z-depth-1" style="padding-bottom: 1%;min-height:100vh" >
				    
				   	 		 <ul class="collection with-header ">
						        <li class="collection-header #00796b teal darken-2 #ffffff white-text"><h5>Welcome, ${this.Admin[keyid].UserName}</h5></li>
						     </ul>
						     <ul>
						     	You're currently using an admin account. Please be advise that you can change the content of the website.
						     </ul>


						     </div>


						    		<div class="col s5">
						    			 <ul class="collapsible" data-collapsible="accordion" style="width: 1000px;margin-left: 2%;margin-top: 5%">
										    <li>
										      <div class="collapsible-header"><i class="material-icons">filter_drama</i>Add</div>
										      <div class="collapsible-body">
										      		<table class="highlight">
										      			<tbody>
										      				<tr>
										      					<td><a href="#" onclick="component.AdminAddVideo('${keyid}')">Video</a></td>
										      				</tr>
										      				<tr>
										      					<td><a href="#" onclick="component.AdminAddChannel('${keyid}')">Channel</a></td>
										      				</tr>
										      			</tbody>

										      		</table>



										      </div>
										    </li>
										    <li>
										      <div class="collapsible-header"><i class="material-icons">place</i>Edit</div>
										      <div class="collapsible-body">
										      		<table class="">
										      			<tbody>
										      				<tr>
										      					<td>


										      						<ul class="collapsible" data-collapsible="accordion">
																	    <li>
																	      <div class="collapsible-header"><i class="material-icons">filter_drama</i>Videos</div>
																	      <div class="collapsible-body">
																	      	
																	      <table class="highlight">
																      			<tbody>
																      				

																      				`; 
																      					for(let x=0; x < this.Videos.length;x++){
																      					html+=`
																      					<tr>
																      					<td><a href="#" onclick="component.AdminEditVideo('${keyid}', '${this.Videos[x].Videoid}')">${this.Videos[x].Title}</a></td>
																      					</tr>

																      					`;
																      				}

																      				html+=`

																      							
																      			
																      				
																      			</tbody>

																      		</table>

																	      </div>
																	    </li>
																	    <li>
																	      <div class="collapsible-header"><i class="material-icons">place</i>Channel</div>
																	      <div class="collapsible-body">
																	      <table class="highlight">
																      			<tbody>
																      				

																      				`; 
																      					for(let x=0; x < this.Channels.length;x++){
																      					html+=`
																      					<tr>
																      					<td><a href="#" onclick="component.AdminEditChannel('${keyid}', '${this.Channels[x].ChannelId}')">${this.Channels[x].ChannelName}</a></td>
																      					</tr>

																      					`;
																      				}

																      				html+=`

																      							
																      			
																      				
																      			</tbody>

																      		</table>



																	      </div>
																	    </li>
																	  </ul>


										      				</td>
										      				</tr>
										      				
										      			</tbody>

										      		</table>




										      </div>
										    </li>
										    <li>
										      <div class="collapsible-header"><i class="material-icons">whatshot</i>Delete</div>
										      <div class="collapsible-body">
										      		<table class="">
										      			<tbody>
										      				<tr>
										      					<td>


										      						<ul class="collapsible" data-collapsible="accordion">
																	    <li>
																	      <div class="collapsible-header"><i class="material-icons">filter_drama</i>Videos</div>
																	      <div class="collapsible-body">
																	      	
																	      <table class="highlight">
																      			<tbody>
																      				

																      				`; let value = 0;
																      					for(let x=0; x < this.Videos.length;x++){
																      						console.log(this.Videos[x].Videoid);
																      					html+=`
																      					<tr>
																      					<td><a href="#${x}" class="modal-trigger")">${this.Videos[x].Title}</a></td>
																      					`; 




																      					html+=`


																      					<div id="${x}" class="modal">
																						    <div class="modal-content">
																						      <h4>WARNING</h4>
																						      <p>Are you sure you want to delete this Video?</p>
																						    </div>

																						    <div class="modal-footer">
																						      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.AdminDeleteVideo('${keyid}', '${this.Videos[x].Videoid}')">Delete</a>
																						      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancel</a>
																						    </div>
																						  </div>
																      					</tr>

																      					`;
																      				}

																      				html+=`

																      							
																      			
																      				
																      			</tbody>

																      		</table>

																	      </div>
																	    </li>
																	    <li>
																	      <div class="collapsible-header"><i class="material-icons">place</i>Channel</div>
																	      <div class="collapsible-body">
																	      <table class="highlight">
																      			<tbody>
																      				

																      				`; 
																      					for(let x=0; x < this.Channels.length;x++){
																      					html+=`
																      					<tr>
																      					<td><a href="#A${x}" class="modal-trigger">${this.Channels[x].ChannelName}</a></td>

																      					<div id="A${x}" class="modal">
																						    <div class="modal-content">
																						      <h4>WARNING</h4>
																						      <p>Are you sure you want to delete this Channel?</p>
																						    </div>
																						    <div class="modal-footer">
																						      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.AdminDeleteChannel('${keyid}','${this.Channels[x].ChannelId}')">Delete</a>
																						      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancel</a>
																						    </div>
																						  </div>



																      					</tr>

																      					`;
																      				}

																      				html+=`

																      							
																      			
																      				
																      			</tbody>

																      		</table>



																	      </div>
																	    </li>
																	  </ul>


										      				</td>
										      				</tr>
										      				
										      			</tbody>

										      		</table>
										      


										      </div>
										    </li>
										  </ul>

						    		</div>







								</div>
								</div>
								<div id="AdminAddVideoPage">
									
								</div>
								<div id="AdminAddChannelPage">
									
								</div>


								<div id="AdminEditVideoPage">
									
								</div>
								<div id="AdminEditChannelPage">
									
								</div>




				</div>






					`;


					document.getElementById("Admin").innerHTML=html;

			}
			AdminDeleteVideo(keyid,vid){

					let pos =0;




							let video = firebase.database().ref('Videos').on('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	console.log(childSnapshot.val().Videoid +" + " + vid);
			        	if(vid == childSnapshot.val().Videoid){
			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			component.DeletedataVideo(pos,keyid,vid);
			        			return;
			        	}
			         
			        }); 

			        
			        					       
			    });


							





				
			}
			DeletedataVideo(pos,keyid,vid){


					let cid = this.Videos[vid].ChannelId;

					let dos =0;
					let loc = 0;

					for(let x = 0; x < this.Channels.length; x++){

						if(this.Channels[cid].ChannelVideo[x] == vid){
							loc = x;
						}


					}
					console.log(loc);




							let video = firebase.database().ref('Channel').on('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	if(cid == childSnapshot.val().ChannelId){
			        			dos = childSnapshot.key;
			        			console.log("this is dos "+ dos);
			        			
			        			console.log(loc);
			        			firebase.database().ref().child('/Channel/'+ dos + '/ChannelVideo/' + loc).remove();



			        			return;
			        	}
			         
			        }); 

			        
			        					       
			    });

							if(this.Channels[cid].ChannelVideo.length == 0){
			        				
			        			}
	



						console.log("in data");
						console.log(vid);
							console.log(pos);
							 this.Videos.splice(vid,1);
							 console.log(pos);


							   firebase.database().ref('Videos').child(pos).remove();
							 console.log(this.Videos);
							
						
							 component.AdminHome(keyid);


							 let channel = {};

							 	firebase.database().ref('Channel/' + pos).set(Channel);



							 Materialize.toast('Successfully Deleted a video!', 4000);










			}


			ChannelIdDelete(dos,vid,div,keyid,cid){

						console.log("delete CHannel Id");


							let contain = [];
	 			for(let x = 0; x <this.Channels[cid].ChannelVideo.length;x++){
	 				if(this.Channels[cid].ChannelVideo[x] != vid)contain.push(this.Channels[cid].ChannelVideo[x]);

	 			}



	 			if(contain.length == 0){
	 				contain.push(" ");
	 			}


		 			
			   
			     
			     firebase.database().ref('Channel/' + dos + '/ChannelVideo/').set(contain);
			     console.log(" this is before "+this.Channels[cid].ChannelVideo.length);
			     let number =0;
			     for(let x=0;0<this.Channels[cid].ChannelVideo.length;x++){
			     	if(this.Channels[cid].ChannelVideo[x] == vid){
			     		number= x;
			     	}
			 }
			 	this.Channels[cid].ChannelVideo.splice(number,1)

			 	console.log(" This is after "+this.Channels[cid].ChannelVideo.length);
			}



			AdminDeleteChannel(keyid,cid){
				
					let pos =0;




							let channel = firebase.database().ref('Channel').on('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	console.log(childSnapshot.val().ChannelId +" + " + cid);
			        	if(cid == childSnapshot.val().ChannelId){
			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			component.DeleteDataChannel(pos,keyid,cid);
			        			return;
			        	}
			         
			        }); 

			        
			        					       
			    });



			}
			DeleteDataChannel(pos,keyid,cid){
				console.log("in data");
						console.log(cid);
							console.log(pos);
							 this.Channels.splice(cid,1);
							 console.log(pos);


							   firebase.database().ref('Channel').child(pos).remove();
							 console.log(this.Channel);
							
			
							 component.AdminHome(keyid);
							 Materialize.toast('Successfully Deleted a channel!', 4000);


















			}

			AdminEditVideo(keyid,vid){
			
			$('#textarea1').val('New Text');
  $('#textarea1').trigger('autoresize');



			$(document).ready(function() {
    $('select').material_select();
  });
				$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
  				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!

				var yyyy = today.getFullYear();
				if(dd<10){
				    dd='0'+dd;
				} 
				if(mm<10){
				    mm='0'+mm;
				} 
				var today = dd+'/'+mm+'/'+yyyy;





				component.HideAdminpage();
				component.ShowAdminEditVideoPage();
				let html=`


						<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.AdminHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.AdminHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					    </div>
			</nav>
							<div class="container">
							<blockquote><h2>Edit Video</h2></blockquote>
							<div class="row" style="margin-top:5%">
							
							        <div class="input-field col s12">
							          <input disabled value="${this.Videos[vid].Videoid}" id="edit_video_id" type="text" class="validate">
							          <label for="disabled" class="active">Video Id</label>
							        </div>
							        
							      </div>
							   <div class="row">
							         <div class="input-field col s6">
							          <input placeholder="" value="${this.Videos[vid].Title}" id="edit_video_title" type="text" class="validate">
							          <label for="first_name" class="active">Video Title</label>
							        </div>






							        <div class="input-field col s6">
									    <select id="edit_video_channel" disabled>
									      <option value="${this.Videos[vid].ChannelId}" selected>${this.Channels[this.Videos[vid].ChannelId].ChannelName}</option>
									      `;
									      for(let x=0; x<this.Channels.length;x++){

									      	html+=`

									      		<option value="${this.Channels[x].ChannelId}">${this.Channels[x].ChannelName}</option>

									      	`;
									      }


									      html+=`
									    </select>
									    <label>Channels</label>
									  </div>

									  <div class="input-field col s6">
									    <select id="edit_video_genre" multiple>
									      <option value="${this.Videos[vid].Genre}"selected>${this.Videos[vid].Genre}</option>
									      <option value="Action">Action</option>
									      <option value="Comedy">Comedy</option>
									      <option value="Slice-Of-Life">Slice-Of-Life</option>
									      <option value="Fantasy">Fantasy</option>
									      <option value="Romance">Romance</option>
									    </select>
									    <label>Genre</label>
									  </div>

									  <div class="input-field col s6">
							          <input disabled value="${this.Videos[vid].VideoDate}" id="edit_video_date" type="text" class="validate">
							          <label for="disabled" class="active">Date</label>
							        </div>
							        <div class="row">
							         <div class="input-field col s6">
							          <input id="edit_video_URL" value="${this.Videos[vid].VideoURL}" type="text" class="validate">
							          <label for="video_URL" class="active">Video Embeded URL</label>
							        </div>

							        <div class="input-field col s6">
							          <input id="edit_video_thumbnail" value="${this.Videos[vid].Thumbnail}" type="text" class="validate">
							          <label for="video_thumbnail" class="active">Video Thumbnail URL</label>
							        </div>





							        
			     				 </div>

			     				 <div class="row">
								    <form class="col s12">
								      <div class="row">
								        <div class="input-field col s12">
								          <textarea id="edit_video_description"class="materialize-textarea">${this.Videos[vid].VideoDescription}</textarea>
								          <label for="video_description" class="active">Video Description</label>
								        </div>
								      </div>
								    </form>
								    <div id="Error" class="row">

								    </div>
								    <div class="col s6">
								  	<a class="waves-effect waves-light btn #b71c1c red darken-4 #ffffff white-text" onclick="component.AdminHome('${keyid}')">Back</a>
								  </div>
								  <div class="col s6">
								  	<a class="waves-effect waves-light btn" onclick="component.AdminEditVideoData('${keyid}','${vid}')">Update</a>
								  </div>
								  </div>
								  

							      </div>
			        </div>
			       



				`;


			document.getElementById("AdminEditVideoPage").innerHTML=html;

			}
			AdminEditVideoData(keyid,vid){
				console.log("Update");

				let video_id = document.getElementById('edit_video_id');
				let video_title = document.getElementById('edit_video_title');
				let video_channel = document.getElementById('edit_video_channel');
				let video_genre = $('#edit_video_genre').val();
				let video_date = document.getElementById('edit_video_date');
				let video_URL = document.getElementById('edit_video_URL');
				let video_thumbnail = document.getElementById('edit_video_thumbnail');
				let video_description = document.getElementById('edit_video_description');
				let likes = this.Videos[vid].VideoLikes;	
			


				console.log(video_genre);
				let videodata = {
					"ChannelId":video_channel.value,
					"Genre":video_genre,
					"Thumbnail":video_thumbnail.value,
					"Title":video_title.value,
					"VideoDate":video_date.value,
					"VideoDescription":video_description.value,
					"VideoLikes":likes,
					"VideoURL":video_URL.value,
					"Videoid":video_id.value
				}

				console.log(videodata);
				if(video_title.value == "" || video_channel.value == "" || video_genre.value == "" || video_URL == "" || video_thumbnail == "" || video_description == ""){
					component.ErrorAdd();
				}
				else{

					let pos =0;




							let channel = firebase.database().ref('Videos').once('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	if(vid == childSnapshot.val().Videoid){

			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			component.EditVideoPush(pos,vid,videodata,keyid);
			        			return;
			        	}
			         
			        }); 

			        

			       
			    });





				
			}






			}


			EditVideoPush(pos,vid,videodata,keyid){



				firebase.database().ref('Videos/' + pos).set(videodata);
				Materialize.toast('Successfully Updated a video!', 4000);
				this.Videos[vid] = videodata;
				component.AdminHome(keyid);








			}
			AdminEditChannel(keyid,cid){
				console.log("edit");
			console.log(cid);


				$('#textarea1').val('New Text');
  $('#textarea1').trigger('autoresize');



			$(document).ready(function() {
    $('select').material_select();
  });
				$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
  				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!

				var yyyy = today.getFullYear();
				if(dd<10){
				    dd='0'+dd;
				} 
				if(mm<10){
				    mm='0'+mm;
				} 
				var today = dd+'/'+mm+'/'+yyyy;







				component.ShowAdminEditChannelPage();
				component.HideAdminpage();
				let html=`<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.AdminHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.AdminHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					    </div>
						</nav>



						<div class="container">
							<blockquote><h2>Edit Channel</h2></blockquote>
							<div class="row" style="margin-top:5%">
							
							        <div class="input-field col s12">
							          <input disabled value="${this.Channels[cid].ChannelId}" id="channel_id" type="text" class="validate">
							          <label for="disabled" class="active">Channel Id</label>
							        </div>
							        
							      </div>
							   <div class="row">
							         <div class="input-field col s6">
							          <input id="channel_name" value="${this.Channels[cid].ChannelName}" type="text" class="validate">
							          <label for="channel_name" class="active">Channel Name</label>
							        </div>

				  

									  <div class="input-field col s6">
							          <input disabled value="${this.Channels[cid].ChannelDate}" id="channel_date" type="text" class="validate">
							          <label for="disabled" class="active">Date</label>

							        </div>
							       
							         

							        <div class="input-field col s6">
							          <input id="channel_picture" type="text" value="${this.Channels[cid].ChannelPicture}" class="validate">
							          <label for="channel_picture" class="active">Channel Poster URL</label>
							        </div>

					        
			     				
							        </div>
			     				 <div class="row">
								    <form class="col s12">
								      <div class="row">
								        <div class="input-field col s12">
								          <textarea id="channel_description" class="materialize-textarea">${this.Channels[cid].ChannelDescription}</textarea>
								          <label for="channel_description" class="active">Video Description</label>
								        </div>
								      </div>
								    </form>
								    <div id="Error">

								    </div>

								    <div class="col s6">
								  	<a class="waves-effect waves-light btn #b71c1c red darken-4 #ffffff white-text" onclick="component.AdminHome('${keyid}')">Back</a>
								  </div>
								  <div class="col s6">
								  	<a class="waves-effect waves-light btn" onclick="component.AdminEditChannelData('${keyid}','${cid}')">Update</a>
								  </div>
								  </div>
								  

							      </div>
			        </div>






			`;
				
			
				
				document.getElementById("AdminEditChannelPage").innerHTML=html;







			}
			AdminEditChannelData(keyid,cid){
				let channel_date = document.getElementById('channel_date');
				let channel_description = document.getElementById('channel_description');
				let channel_id = document.getElementById('channel_id');
				let channel_name = document.getElementById('channel_name');
				let channel_picture = document.getElementById('channel_picture');
				let channel_saved = [];

				for(let x=0;x < this.Channels[cid].ChannelVideo.length;x++){
						channel_saved.push(this.Channels[cid].ChannelVideo[x])
				}

				console.log(channel_saved)



				let channeldata = {
					"ChannelDate":channel_date.value,
					"ChannelDescription":channel_description.value,
					"ChannelId":channel_id.value,
					"ChannelName":channel_name.value,
					"ChannelPicture":channel_picture.value,
					"ChannelVideo":channel_saved
					

				};
				console.log(channeldata);


				if(channel_description.value == " " || channel_name.value == " " || channel_picture.value == " "){
					component.ErrorAdd();
				}


					else{
					console.log(channeldata);
				

				 let pos =0;




							let channel = firebase.database().ref('Channel').once('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	if(cid == childSnapshot.val().ChannelId){
			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			component.editPush(cid,pos,channeldata,keyid);
			        			return;
			        	}
			         
			        }); 
			        	
			        

			       
			    });









}

					

			}
			editPush(cid,pos,channeldata,keyid){
				console.log("Edit");
										firebase.database().ref('Channel/' + pos).set(channeldata);

				Materialize.toast('Successfully Updated a Channel!', 4000);

				this.Channels[cid] = channeldata;
				component.AdminHome(keyid);
			}



			AdminAddVideo(keyid){
				console.log("this is channel "+ this.Channels.length);
			$('#textarea1').val('New Text');
  $('#textarea1').trigger('autoresize');



			$(document).ready(function() {
    $('select').material_select();
  });
				$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
  				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!

				var yyyy = today.getFullYear();
				if(dd<10){
				    dd='0'+dd;
				} 
				if(mm<10){
				    mm='0'+mm;
				} 
				var today = dd+'/'+mm+'/'+yyyy;





				component.HideAdminpage();
				component.ShowAdminAddVideo();
				let html=`


						<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.AdminHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.AdminHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					    </div>
			</nav>
							<div class="container">
							<blockquote><h2>Add Video</h2></blockquote>
							<div class="row" style="margin-top:5%">
							
							        <div class="input-field col s12">
							          <input disabled value="`; 

							        	var val = 0;
							        	for(let x = 0; x<this.Videos.length;x++){
							        		
										
												val = parseInt(this.Videos[x].Videoid);
												

																					}
													val = val + 1;								




							        html+=`${val}" id="video_id" type="text" class="validate">
							          <label for="disabled" class="active">Video Id</label>
							        </div>
							        
							      </div>
							   <div class="row">
							         <div class="input-field col s6">
							          <input id="video_title" type="text" class="validate">
							          <label for="video_title">Title</label>
							        </div>






							        <div class="input-field col s6">
									    <select id="video_channel">
									      <option value="" disabled selected>Choose your option</option>
									      `;
									      for(let x=0; x<this.Channels.length;x++){

									      	html+=`

									      		<option value="${this.Channels[x].ChannelId}">${this.Channels[x].ChannelName}</option>

									      	`;
									      }


									      html+=`
									    </select>
									    <label>Channels</label>
									  </div>

									  <div class="input-field col s6">
									    <select id="video_genre" multiple>
									      <option value="" disabled selected>Pick a Genre</option>
									      <option value="Action">Action</option>
									      <option value="Comedy">Comedy</option>
									      <option value="Slice-Of-Life">Slice-Of-Life</option>
									      <option value="Fantasy">Fantasy</option>
									      <option value="Romance">Romance</option>
									    </select>
									    <label>Genre</label>
									  </div>

									  <div class="input-field col s6">
							          <input disabled value="${today}" id="video_date" type="text" class="validate">
							          <label for="disabled" class="active">Date</label>
							        </div>
							        <div class="row">
							         <div class="input-field col s6">
							          <input id="video_URL" type="text" class="validate">
							          <label for="video_URL">Video Embeded URL</label>
							        </div>

							        <div class="input-field col s6">
							          <input id="video_thumbnail" type="text" class="validate">
							          <label for="video_thumbnail">Video Thumbnail URL</label>
							        </div>





							        
			     				 </div>

			     				 <div class="row">
								    <form class="col s12">
								      <div class="row">
								        <div class="input-field col s12">
								          <textarea id="video_description" class="materialize-textarea"></textarea>
								          <label for="video_description">Video Description</label>
								        </div>
								      </div>
								    </form>
								    <div id="Error" class="row">

								    </div>
								    <div class="col s6">
								  	<a class="waves-effect waves-light btn #b71c1c red darken-4 #ffffff white-text" onclick="component.AdminHome('${keyid}')">Back</a>
								  </div>
								  <div class="col s6">
								  	<a class="waves-effect waves-light btn" onclick="component.AdminAddVideoData('${keyid}')">Add</a>
								  </div>
								  </div>
								  

							      </div>
			        </div>
			       



				`;


				document.getElementById("AdminAddVideoPage").innerHTML=html;
			}
			ErrorAdd(){
				let html=`<h5 class="#b71c1c red-text text-darken-4 center-align col s12">Please fill in all information</h5>`;
				document.getElementById("Error").innerHTML=html;
			}
			AdminAddVideoData(admin){


				let video_id = document.getElementById('video_id');
				let video_title = document.getElementById('video_title');
				let video_channel = document.getElementById('video_channel');
				let video_genre = $('#video_genre').val();
				let video_date = document.getElementById('video_date');
				let video_URL = document.getElementById('video_URL');
				let video_thumbnail = document.getElementById('video_thumbnail');
				let video_description = document.getElementById('video_description');
				let keyid = video_channel.value;






				let videodata = {
					"ChannelId":video_channel.value,
					"Genre":video_genre,
					"Thumbnail":video_thumbnail.value,
					"Title":video_title.value,
					"VideoDate":video_date.value,
					"VideoDescription":video_description.value,
					"VideoLikes":0,
					"VideoURL":video_URL.value,
					"Videoid":video_id.value
				}
				console.log(videodata);

				if(video_title.value == "" || video_channel.value == "" || video_genre.value == "" || video_URL == "" || video_thumbnail == "" || video_description == ""){
					component.ErrorAdd();
				}
				else{









				let userid = firebase.database().ref().child('Member').push().key; 

					let updates = {};
				    updates['/Videos/'+userid] = videodata;
				    firebase.database().ref().update(updates);
					Materialize.toast('Successfully add a video!', 4000);

						this.Videos.push(videodata);
						let pos =0;




							let channel = firebase.database().ref('Channel').once('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	if(keyid == childSnapshot.val().ChannelId){
			        			pos = childSnapshot.key;
			        			console.log(pos+ " Out Pos");
			        		
			        			
			        	}
			         
			        }); 

			        	component.LastAddData(pos,keyid,admin,video_id.value);

			       
			    });

							

							}	   
			}
			LastAddData(pos,keyid,admin,video_id){
				console.log(keyid);

				console.log("Inner");
				console.log(pos);
						let storage = [];
	 			for(let x = 0; x<this.Channels[keyid].ChannelVideo.length;x++){

	 				console.log(this.Channels[keyid].ChannelVideo);
	 				if(this.Channels[keyid].ChannelVideo[x] != " ")storage.push(this.Channels[keyid].ChannelVideo[x]);
	 				console.log(storage);

	 			}

	 				console.log(storage);
				
	 					storage.push(video_id);
	 				
	 					console.log(storage);


					


					firebase.database().ref('Channel/' + pos + '/ChannelVideo/' ).set(storage);
							this.Channels[keyid].ChannelVideo.push(video_id);
							component.AdminHome(admin);



			}
			AdminAddChannel(keyid){


				$('#textarea1').val('New Text');
  $('#textarea1').trigger('autoresize');



			$(document).ready(function() {
    $('select').material_select();
  });
				$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
  				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!

				var yyyy = today.getFullYear();
				if(dd<10){
				    dd='0'+dd;
				} 
				if(mm<10){
				    mm='0'+mm;
				} 
				var today = dd+'/'+mm+'/'+yyyy;







				component.ShowAdminAddChannelPage();
				component.HideAdminpage();
				component.HideAdminAddVideo();
				let html=`<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-1">
					      <a href="#" onclick="component.AdminHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.AdminHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					    </div>
						</nav>



						<div class="container">
							<blockquote><h2>Add Channel</h2></blockquote>
							<div class="row" style="margin-top:5%">
							
							        <div class="input-field col s12">
							          <input disabled value="${this.Channels.length}" id="channel_id" type="text" class="validate">
							          <label for="disabled" class="active">Channel Id</label>
							        </div>
							        
							      </div>
							   <div class="row">
							         <div class="input-field col s6">
							          <input id="channel_name" type="text" class="validate">
							          <label for="channel_name">Channel Name</label>
							        </div>

				  

									  <div class="input-field col s6">
							          <input disabled value="${today}" id="channel_date" type="text" class="validate">
							          <label for="disabled" class="active">Date</label>

							        </div>
							       
							         

							        <div class="input-field col s6">
							          <input id="channel_picture" type="text" class="validate">
							          <label for="channel_picture">Channel Poster URL</label>
							        </div>

					        
			     				
							        </div>
			     				 <div class="row">
								    <form class="col s12">
								      <div class="row">
								        <div class="input-field col s12">
								          <textarea id="channel_description" class="materialize-textarea"></textarea>
								          <label for="channel_description">Channel Description</label>
								        </div>
								      </div>
								    </form>
								    <div id="Error">

								    </div>

								    <div class="col s6">
								  	<a class="waves-effect waves-light btn #b71c1c red darken-4 #ffffff white-text" onclick="component.AdminHome('${keyid}')">Back</a>
								  </div>
								  <div class="col s6">
								  	<a class="waves-effect waves-light btn" onclick="component.AdminAddChannelData('${keyid}')">Add</a>
								  </div>
								  </div>
								  

							      </div>
			        </div>










			`;
				
			
				
				document.getElementById("AdminAddChannelPage").innerHTML=html;
			}
			AdminAddChannelData(keyid){
				let channel_date = document.getElementById('channel_date');
				let channel_description = document.getElementById('channel_description');
				let channel_id = document.getElementById('channel_id');
				let channel_name = document.getElementById('channel_name');
				let channel_picture = document.getElementById('channel_picture');


				let channeldata = {
					"ChannelDate":channel_date.value,
					"ChannelDescription":channel_description.value,
					"ChannelId":channel_id.value,
					"ChannelName":channel_name.value,
					"ChannelPicture":channel_picture.value,
					"ChannelVideo":[" "]
					

				};



					if(channel_description.value == "" || channel_name.value == "" || channel_picture.value == ""){
					component.ErrorAdd();
				}


					else{
					console.log(channeldata);
				let userid = firebase.database().ref().child('Channel').push().key; 

					let updates = {};
				    updates['/Channel/'+userid] = channeldata;
				    firebase.database().ref().update(updates);
					Materialize.toast('Successfully add a Channel!', 4000);
					this.Channels.push(channeldata);
					component.AdminHome(keyid);




}



			}






		MemberHome(keyid){
			$(document).ready(function(){
			    $('ul.tabs').tabs();
			  });
			$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });

			component.HideAllGuest();
			component.ShowAllMember();
		

			let html=`
			<div id="MemberHomePage">
			<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-0">
					      <a href="#" onclick="component.MemberHome('${keyid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.MemberHome('${keyid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="#">Welcome, ${this.Members[keyid].UserName}</a></li>
      </ul>
					    </div>
			</nav>
			
			<div class="row">
			<div class="col s12">
				    <div class="row z-depth-1">
					    <div class="col s12 ">
					      <ul class="tabs tabs-fixed-width ">
					        <li class="tab col s4 hoverable"><a href="#test1mem" class="#00897b teal-text text-darken-1">Watched</a></li>
					        <li class="tab col s4 hoverable"><a href="#test2mem" class="#00897b teal-text text-darken-1">Browse</a></li>					        
					        <li class="tab col s4 hoverable"><a href="#test3mem" class="#00897b teal-text text-darken-1">Channels</a></li>
					      </ul>
					    </div>


					    <div id="test1mem" class="col s12">
					    	

					    <div id="Watched" class="row">
					   
					    </div>



					    </div>
					    <div id="test2mem" class="col s12">
					    	<div id="BrowseMember" class="row">

					    	</div>
					    </div>
					    <div id="test3mem" class="col s12">
					    	<div id="ChannelMem" class="row">

					    	</div>
					    </div>
					    </div>
					</div>
				</div>
				</div>
				</div>

				<div id="MemberVideo">

				</div>
				<div id="MemberChannel">

				</div>

			`;

			document.getElementById("AllMember").innerHTML=html;
			component.ReadBrowseMember(keyid);
			component.ReadChannelMember(keyid);
			component.ReadMemberWatch(keyid);
			component.HideAllGuest();
			component.ShowAllMember();

		}

		ReadMemberWatch(key){
		

			
			let html=`
			<br>
			<blockquote><h5>Watch List</h5></blockquote>
			<div class="collection">
			`;
			for(let x=0;x<this.Members[key].ChannelSaved.length;x++){
				console.log(x);
				html+=`
						  

											
					        					  


					         

					         <div id="hoverani" class="col s12 m4" href="#" onclick="component.ReadMemberViewChannel(${this.Members[key].ChannelSaved[x]},'${key}')" style="cursor:pointer">
						          <div class="card #ff8f00 amber darken-3 hoverable">
						            <div class="card-content white-text">
						              <span class="card-title">${this.Channels[this.Members[key].ChannelSaved[x]].ChannelName}</span>
						              <p class="truncate">${this.Channels[this.Members[key].ChannelSaved[x]].ChannelDescription}</p>
						            </div>
						            
						          </div>
						        </div>




				`;
			}
			html+=`
			</div>`;
			
			document.getElementById("Watched").innerHTML=html;
		}
		ReadBrowseMember(keyid){
			let	html=`
			<br>
			<blockquote>
     		<h5>All Videos</h5>
   			 </blockquote>

			<div class="row">
			`;


			for(let x=0;x<this.Videos.length;x++){
				let ID= this.Videos[x].Videoid;
			html+=`

				
			   



			        <div class="col s3">
			     	   <a href="#" onclick="component.ReadMemberVideo('${ID}','${keyid}');">
			          <div class="card z-depth-0" style="">
			          	<div class="hoverable">         
			            <div class="card-image" style="">
			              <img style ="height:250px" src="${this.Videos[x].Thumbnail}">			              
			            </div>
			             

			          	</div>
			          	 <span class="card-title #757575 grey-text text-darken-1 center-align" ><h5>${this.Videos[x].Title}</h5></span>
			          </div>
			          </a>
			        </div>

			     
			      	`;

			}

			html+=`
			</div>
			</div>
			`;
			document.getElementById("BrowseMember").innerHTML=html;


		}
		ReadMemberVideo(key,memid){
			console.log("member");
			component.HideMemberHomePage();
			component.HideChannelMember();
			component.ShowMemberVideo();
			$('#ChannelMem').hide();
			$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });

			let Cid = this.Videos[key].ChannelId;
			let html=`
				
				<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-0">
					      <a href="#" onclick="component.MemberHome('${memid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.MemberHome('${memid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="#">Welcome, ${this.Members[memid].UserName}</a></li>
      </ul>
					    </div>
				</nav>

				<div class="container">
				<div class="row">
					<div class="col m12" style="margin-top:2%">
								<div class="video-container">
							        <iframe width="500" height="200" src="${this.Videos[key].VideoURL}" frameborder="0" allowfullscreen></iframe>
							     </div>
					</div>
					<div class="col m6">
						<ul class="collection with-header">
					        <li class="collection-header"><h4>${this.Videos[key].Title}</h4></li>
					        <li class="collection-item">${this.Videos[key].VideoDescription}</li>
					        <li class="collection-item">Genre:
					        `;
					        for(let x=0; x<this.Videos[key].Genre.length;x++){
					        	html+=`
					        		${this.Videos[key].Genre[x]}

					        	`;
					        	if(x<this.Videos[key].Genre.length-1){
					        		html+=`
					        		,`;
					        	}
					        }

					        html+=`

					        </li>
					        
					      </ul>

					</div>
					
					<div class="col m6">
						<ul class="collection with-header">
					        <li class="collection-header">View more of <a href="#" onclick="component.ReadMemberViewChannel('${Cid}','${memid}')">${this.Channels[Cid].ChannelName}</a></li>
					    </ul>
					</div>
				</div>
				</div>



			`;
			
		document.getElementById("MemberVideo").innerHTML=html;


		}
		ReadMemberViewChannel(key,keyid){

				  $(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
      



			let memid=keyid;
			console.log("this is key = "+ key +" this is keyid = "+ keyid);
			component.ShowChannelMember();
			component.HideMemberHomePage();
			component.HideMemberVideo();
				let html=`
				<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-0">
					      <a href="#" onclick="component.MemberHome('${memid}')" class="brand-logo center ">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" onclick="component.MemberHome('${memid}')">Home</a></li>
					        <li><a class="waves-effect waves-light btn modal-trigger" href="#modal1">Sign out</a>

					        	<div id="modal1" class="modal">
							    <div class="modal-content">
							      
							      <p class="#00695c teal-text text-darken-3">Are you sure you want to sign out?</p>
							    </div>
							    <div class="modal-footer">
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="component.indexPage()">Agree</a>
							      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Disagree</a>
							    </div>
							  </div>


					        </li>
					      </ul>
					      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="#">Welcome, ${this.Members[memid].UserName}</a></li>
      </ul>
					    </div>
				</nav>








				<div class="container" style="margin-top:3%;">
					<div class="row">
						<div class="col m6">
						<img class="responsive-img" src="${this.Channels[key].ChannelPicture}" style="height:300px">
						<div class="col m12" style="margin-left: -2%">
								<blockquote class="col m12"><h3>${this.Channels[key].ChannelName}</h3></blockquote>
								<div class="col m12">
									${this.Channels[key].ChannelDescription}
									</div>
						</div>
						</div>
						<div class="col m6">
									<div id="WatchStatus" class="col 3">
										
									</div>
									<table class="highlight">
								        <thead>
								          <tr>
								              <th>EPISODES</th>							         
								          </tr>
								        </thead>
								        <tbody>
								        `;
								           for(let x=0;x<this.Channels[key].ChannelVideo.length;x++){
								          	if(this.Channels[key].ChannelVideo[x] != " "){
								          		let id = this.Channels[key].ChannelVideo[x];
								          		let Vid = 0;
								          		let loc = 0;
								          		console.log(this.Channels[key].ChannelVideo[x])
								          		for(let y = 0; y<this.Videos.length;y++){
								          			if(this.Channels[key].ChannelVideo[x] == this.Videos[y].Videoid){
								          				Vid = this.Videos[y].Videoid;
								          				loc = y;
								          			}
								          		}
								          		console.log(Vid);
								          		

								          	html+=`

								          


								         	 <tr class="#ff8f00 amber darken-3 hoverable" style="cursor:pointer" onclick ="component.ReadMemberVideo('${loc}','${memid}');">
								           		 <td><h6><a href="#" onclick ="component.ReadMemberVideo('${loc}','${memid}');" class="#00695c #ffffff white-text">${this.Videos[loc].Title}</a></h6></td>				            
								         	 </tr>



								          	`;

								          	}
								          	else{
								          		html+=`


								          		<tr>
								          			<td>No Videos</td>
								          		</tr>
								          		`;
								          	}




								          }

								          html+=`
								        </tbody>
								      </table>
						</div>
						
					</div>

				</div>



			`;
			
		document.getElementById("MemberChannel").innerHTML=html;
		component.ReadWatch(key,keyid);
		}
		ReadWatch(key,keyid){


			
			let html=``;

									for(let x=0,counter = 0;x<this.Members[keyid].ChannelSaved.length;x++){
										console.log(this.Members[keyid].ChannelSaved[x]);
										console.log(key);
											if(this.Members[keyid].ChannelSaved[x] == key){
												html =`<blockquote><h5>Watch<a href="#" onclick="component.DeleteChannel('${key}','${keyid}')"> <i class="material-icons #e57373 red-text text-lighten-2">close</i></a></h5></blockquote>`;
												break;
											}
											else if(counter == x){
												html=`<blockquote><h5>Not Watch <a href="#" onclick="component.AddChannel('${key}','${keyid}')"><i class="material-icons">playlist_add</i></a></h5></blockquote>`;
											}
											counter++;
												
										}
			document.getElementById("WatchStatus").innerHTML=html;				

		}
		AddChannel(key,keyid){
				console.log(keyid);
				
		
	 let pos = 0;

	 			let member = firebase.database().ref('Member').once('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	if(keyid == childSnapshot.val().MemberId){
			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			
			        			
			        	}
			         
			        }); 


			        console.log(this.Members[keyid].ChannelSaved.length);

	 			
			
	 			let contain = [];
	 			for(let x = 0; x <this.Members[keyid].ChannelSaved.length;x++){

	 				console.log(this.Members[keyid].ChannelSaved[x]);
	 				if(this.Members[keyid].ChannelSaved[x] == ""){
	 						console.log("empty");
	 				}
	 				else{
	 					contain.push(this.Members[keyid].ChannelSaved[x]);
	 				}

	 			}
	 			console.log(contain);


	

	 			


				console.log(pos);	
			   	
	 			contain.push(key);
	 			console.log(contain)
	 			
			   
			     
			     firebase.database().ref('Member/' + pos + '/ChannelSaved/').set(contain);
				 this.Members[keyid].ChannelSaved = contain;


				component.MemberHome(keyid);
				

			        

			       
			    });


	 			
	 			 Materialize.toast('Successfully Add', 4000);


	 			






		}
		DeleteChannel(key,keyid){

			let contain = [];
	 			for(let x = 0; x<this.Members[keyid].ChannelSaved.length;x++){

	 				console.log(this.Members[x].ChannelSaved);
	 				if(key != this.Members[keyid].ChannelSaved[x]){
	 				contain.push(this.Members[keyid].ChannelSaved[x]);

	 			}
	 		}		
	 			console.log(contain);
	 			if(contain.length == 0){
	 				contain.push("");
	 			}


	 			let pos = 0;

	 			let member = firebase.database().ref('Member').once('value', 
			      (snapshot)=>{
			      
			        snapshot.forEach(function(childSnapshot) {
			        	console.log(childSnapshot.key);
			        	if(keyid == childSnapshot.val().MemberId){
			        			pos = childSnapshot.key;
			        			console.log(pos);
			        			
			        			
			        	}
			         
			        }); 


			        console.log(contain)
				 firebase.database().ref('Member/' + pos + '/ChannelSaved/').set(
				 	contain
				 	

				);
				 this.Members[keyid].ChannelSaved = contain;

				Materialize.toast('Successfully Delete', 4000);

				component.MemberHome(keyid);



			        });






	 			







		}
		ReadChannelMember(keyid){

			let	html=`
			<br>
			<blockquote>
     		<h5>All Channels</h5>
   			 </blockquote>

			<div class="row">
			<div class="collection">
						`; 
							for(let x=0;x<this.Channels.length;x++){
								let ID = this.Channels[x].ChannelId;
								
								html+=`

				

				  

				   <div id="hoverani" class="col s12 m6" href="#" onclick="component.ReadMemberViewChannel('${ID}','${keyid}')" style="cursor:pointer">
						          <div class="card #ff8f00 amber darken-3 hoverable">
						            <div class="card-content white-text">
						              <span class="card-title">${this.Channels[x].ChannelName}</span>
						              <p class="truncate">${this.Channels[x].ChannelDescription}</p>
						            </div>
						            
						          </div>
						        </div>



								`;
							}

						html+=`
			</div>
			</div>
		
		

		
			`;
			document.getElementById("ChannelMem").innerHTML=html;


		}





}
class Component extends App{
	constructor(){
		super();}

indexPage(){
			
		console.log(this.Members);	
		console.log(this.Videos);
		console.log(this.Channels);
		$(document).ready(function(){
   		 $('ul.tabs').tabs();
 		 });
	
			let html = `

			<div id="AllGuest">

				<div id="GuestHome">

					
					<nav class="z-depth-0">
					    <div class="nav-wrapper #00796b teal darken-2 z-depth-0">
					      <a href="#" onclick="component.indexPage()" class="brand-logo center">WebKultura</a>
					      <ul id="nav-mobile" class="right hide-on-med-and-down ">
					        <li><a href="#" class="#e0e0e0" onclick="component.indexPage()">Home</a></li>
					        <li><a href="#" class="#e0e0e0" onclick="component.ReadGuestAbout()">About</a></li>
					      </ul>
					    </div>
				    </nav>


				    <div class="row">

				    <div id="Register" class="collection col s3 z-depth-1" style="min-height:100vh">
				    
				   	 		 <ul class="collection with-header ">
						        <li class="collection-header #00796b teal darken-2 #ffffff white-text"><h5>Welcome</h5></li>
						     </ul>


						     <div class="row">
						     <h5 style="margin-left:5%">Login</h5> 
						     	<div class="input-field col s12">
						          <input id="Username" type="text" class="validate">
						          <label for="Username">Username</label>
						        </div>
						        <div class="input-field col s12">
						          <input id="password" type="password" class="validate">
						          <label for="password">Password</label>
						        </div>
						     </div>
						     <div class="row">
						     		<div id="ErrorUser" class="center-align #c62828 red-text text-darken-3"> </div>
						     		
						     </div>

						     <div class="row">
						     	<a class="waves-effect waves-light btn col s4 offset-s1 #00796b teal darken-2" onclick="component.ReadLogin()">Login</a>
						     	<a class="waves-effect waves-light btn col s4 offset-s2 #ff1744 red accent-3" onclick="component.ReadRegisterPage()">Sign Up</a>
						     </div>


				    </div>




				    <div class="col s9">
				    <div class="row z-depth-1">
					    <div class="col s12 ">
					      <ul class="tabs">
					        <li class="tab col s4 hoverable"><a href="#test1" class="#00897b teal-text text-darken-1">What's New</a></li>
					        <li class="tab col s4 hoverable"><a href="#test2" class="#00897b teal-text text-darken-1">Browse</a></li>					        
					        <li class="tab col s4 hoverable"><a href="#test3" class="#00897b teal-text text-darken-1">Channels</a></li>
					      </ul>
					    </div>


					    <div id="test1" class="col s12">

					    <div id="WhatNew" class="row">
					    </div>



					    </div>
					    <div id="test2" class="col s12">
					    	<div id="Browse" class="row">

					    	</div>
					    </div>
					    <div id="test3" class="col s12">
					    	<div id="Channel" class="row">

					    	</div>
					    </div>
					    </div>
					</div>
					</div>
					</div>

					<div id="GuestViewChannel">
						
					</div>
					<div id="GuesViewVideo">
						
					</div>

					<div id="GuestRegister">
						
					</div>

					<div id="GuestAbout">
					</div>
					</div>


					<div id="AllMember">

					</div>
					<div id="Admin">
					</div>



				`;
			document.getElementById("Site").innerHTML=html;	
			component.readsWhatNew();
			component.ReadBrowseGuest();
			component.ReadChannelGuest();
			component.HideAllMember();
			component.ShowAllGuest();
			


	}







	HideGuestHome(){
		$('#GuestHome').hide();

	}
	HideAllMember(){
		$('#AllMember').hide();

	}
	HideMemberVideo(){
		$('#MemberVideo').hide();
	}
	HideMemberHomePage(){
		$('#MemberHomePage').hide();
	}
	HideGuestVideo(){
		$('#GuesViewVideo').hide();
	}
	HideGuestChannel(){
		$('#GuestViewChannel').hide();
	}
	HideGuestAbout(){
		$('#GuestAbout').hide();
	}
	HideGuestRegister(){
		$('#GuestRegister').hide();
	}
	HideAllGuest(){
		$('#AllGuest').hide();
	}
	HideChannelMember(){
		$('#MemberChannel').hide();
	}
	HideAllAdmin(){
		$('#AllAdmin').hide();
	}
	HideAdminAddVideo(){
		$('#AdminAddVideoPage').hide();
	}
	HideAdminpage(){
		$('#Adminpage').hide();
	}
	HideAdminAddChannelPage(){
		$('#AdminAddChannelPage').hide();
	}
	HideAdminEditVideoPage(){
		$('#AdminEditVideoPage').hide();
	}
	HideAdminEditChannelPage(){
		$('#AdminEditChannel').hide();
	}
	ShowGuestHome(){
		$('#GuestHome').show();

	}
	ShowMemberVideo(){
	
		$('#MemberVideo').show();
	}
	ShowMemberHomePage(){
		$('#MemberHomePage').show();
	}
	ShowGuestVideo(){
		$('#GuesViewVideo').show();
	}
	showGuestChannel(){
		$('#GuestViewChannel').show();
	}
	ShowGuestAbout(){
		$('#GuestAbout').show();
	}
	ShowGuestRegister(){
		$('#GuestRegister').show();
	}
	ShowAllGuest(){
		$('#AllGuest').show();
	}
	ShowAllMember(){
		$('#AllMember').show();
	}
	ShowChannelMember(){
		$('#MemberChannel').show();
	}
	ShowAllAdmin(){
		$('#AllAdmin').show();
	}
	ShowAdminAddVideo(){
		$('#AdminAddVideoPage').show();
	}
	ShowAdminpage(){
		$('#Adminpage').show();
	}
	ShowAdminAddChannelPage(){
		$('#AdminAddChannelPage').show();
	}
	ShowAdminEditVideoPage(){
		$('#AdminEditVideoPage').show();
	}
	ShowAdminEditChannelPage(){
		$('#AdminEditChannel').show();
	}


	
}

let component = new Component();




